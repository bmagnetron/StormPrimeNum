Release History & Change Log
=============================

0.1.0 : First release.

0.2.0 : First stable release.

1.0.0 : Support for both Python2 and Python3

1.0.1 : Few bug fixes to address format changes.

1.0.3 : Fixed encoding bug. End of offical python 2 support.

1.0.5 : Handled url format change in nseindia website
