.. nsetools documentation master file, created by
   sphinx-quickstart on Fri Jan  2 02:11:40 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to nsetools's documentation!
====================================

Python library for extracting realtime data from National Stock Exchange (India)

Table Of Contents
================

.. toctree::
   :maxdepth: 2

   introduction
   usage
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. disqus::
 
